# FITB Current Results Summary

Generated from completed local runs. MCQ comparisons are computed on the same numeric no-unit 182-item subset unless otherwise noted. Token columns count input plus output tokens. Step/call columns count model calls per question; for one-shot runs this is 1.0 by construction.

## Completed FITB Runs

| Run | Correct | Accuracy | Graded | Ungraded | Errors | Elapsed (s) | Input tok | Output tok | Total tok | Tok/q | Calls/q |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-5.4 direct | 2/182 | 1.1% | 182 | 0 | 0 | 39.3 | 23,102 | 1,879 | 24,981 | 137 | 1.0 |
| GPT-5.4 CoT | 4/182 | 2.2% | 180 | 2 | 0 | 271.3 | 29,290 | 62,288 | 91,578 | 503 | 1.0 |
| GPT-5.4 + TOC | 101/182 | 55.5% | 182 | 0 | 0 | 937.1 | 7,803,147 | 64,119 | 7,867,266 | 43,227 | 8.1 |
| GPT-5.4 + Raw100k | 105/182 | 57.7% | 182 | 0 | 0 | 862.1 | 11,043,795 | 56,307 | 11,100,102 | 60,990 | 7.0 |
| GPT-5.4 + Raw500k | 107/182 | 58.8% | 182 | 0 | 0 | 972.8 | 21,533,625 | 59,131 | 21,592,756 | 118,642 | 7.0 |
| Claude Sonnet 4.6 direct | 8/182 | 4.4% | 182 | 0 | 0 | 677.0 | 25,970 | 156,624 | 182,594 | 1,003 | 1.0 |
| Claude Sonnet 4.6 CoT | 7/182 | 3.8% | 181 | 1 | 0 | 789.2 | 31,982 | 198,267 | 230,249 | 1,265 | 1.0 |
| Claude Sonnet 4.6 + TOC | 116/182 | 63.7% | 181 | 1 | 1 | 3590.9 | 11,020,655 | 217,565 | 11,238,220 | 61,748 | 7.9 |
| Claude Opus 4.6 direct | 12/182 | 6.6% | 182 | 0 | 0 | 968.0 | 25,970 | 181,298 | 207,268 | 1,139 | 1.0 |
| Claude Opus 4.6 CoT | 14/182 | 7.7% | 181 | 1 | 0 | 982.3 | 31,982 | 195,284 | 227,266 | 1,249 | 1.0 |

## MCQ vs FITB, Matched 182-Item Subset

| Method | MCQ | FITB | Drop (pp) | MCQ total tok | FITB total tok | MCQ tok/q | FITB tok/q | MCQ calls/q | FITB calls/q |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-5.4 direct | 48/182 (26.4%) | 2/182 (1.1%) | -25.3 | 32,156 | 24,981 | 177 | 137 | 1.0 | 1.0 |
| GPT-5.4 CoT | 60/182 (33.0%) | 4/182 (2.2%) | -30.8 | 82,709 | 91,578 | 454 | 503 | 1.0 | 1.0 |
| GPT-5.4 + TOC | 131/182 (72.0%) | 101/182 (55.5%) | -16.5 | 10,625,428 | 7,867,266 | 58,381 | 43,227 | 9.4 | 8.1 |
| GPT-5.4 + Raw100k | 127/182 (69.8%) | 105/182 (57.7%) | -12.1 | 12,820,358 | 11,100,102 | 70,442 | 60,990 | 7.4 | 7.0 |
| GPT-5.4 + Raw500k | 133/182 (73.1%) | 107/182 (58.8%) | -14.3 | 21,357,632 | 21,592,756 | 117,350 | 118,642 | 7.2 | 7.0 |
| Claude Sonnet 4.6 direct | 68/182 (37.4%) | 8/182 (4.4%) | -33.0 | 35,184 | 182,594 | 193 | 1,003 | 1.0 | 1.0 |
| Claude Sonnet 4.6 CoT | 77/182 (42.3%) | 7/182 (3.8%) | -38.5 | 239,966 | 230,249 | 1,318 | 1,265 | 1.0 | 1.0 |
| Claude Sonnet 4.6 + TOC | 155/182 (85.2%) | 116/182 (63.7%) | -21.4 | 18,628,237 | 11,238,220 | 102,353 | 61,748 | 10.5 | 7.9 |
| Claude Opus 4.6 direct | 71/182 (39.0%) | 12/182 (6.6%) | -32.4 | 128,180 | 207,268 | 704 | 1,139 | 1.0 | 1.0 |
| Claude Opus 4.6 CoT | 63/182 (34.6%) | 14/182 (7.7%) | -26.9 | 225,496 | 227,266 | 1,239 | 1,249 | 1.0 | 1.0 |

## GPT-5.4 Agent Conditions, Last-36 Large-Output Subset

| Method | MCQ | FITB | Drop (pp) | MCQ tok/q | FITB tok/q | MCQ calls/q | FITB calls/q |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-5.4 + TOC | 29/36 (80.6%) | 22/36 (61.1%) | -19.4 | 52,900 | 35,349 | 9.6 | 7.7 |
| GPT-5.4 + Raw100k | 25/36 (69.4%) | 24/36 (66.7%) | -2.8 | 45,207 | 38,918 | 7.1 | 6.7 |
| GPT-5.4 + Raw500k | 28/36 (77.8%) | 25/36 (69.4%) | -8.3 | 47,527 | 37,946 | 7.2 | 6.6 |

## GPT-5.4 Large-Output Agreement Breakdown

| Method | Subset | Items | Both correct | MCQ-only | FITB-only | Both wrong |
| --- | --- | --- | --- | --- | --- | --- |
| GPT-5.4 + TOC | source 165-200 | 36 | 20 | 9 | 2 | 5 |
| GPT-5.4 + TOC | source 165-181 | 17 | 1 | 9 | 2 | 5 |
| GPT-5.4 + TOC | source 182-200 | 19 | 19 | 0 | 0 | 0 |
| GPT-5.4 + Raw100k | source 165-200 | 36 | 19 | 6 | 5 | 6 |
| GPT-5.4 + Raw100k | source 165-181 | 17 | 2 | 6 | 3 | 6 |
| GPT-5.4 + Raw100k | source 182-200 | 19 | 17 | 0 | 2 | 0 |
| GPT-5.4 + Raw500k | source 165-200 | 36 | 21 | 7 | 4 | 4 |
| GPT-5.4 + Raw500k | source 165-181 | 17 | 3 | 6 | 4 | 4 |
| GPT-5.4 + Raw500k | source 182-200 | 19 | 18 | 1 | 0 | 0 |
