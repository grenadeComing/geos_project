# MCQ vs FITB Agent Comparison

All comparisons use the same 182 numeric no-unit source items. FITB exact uses numeric equivalence, so scientific notation is valid. Budget columns count input plus output tokens over the same 182 items; steps are model calls per question from the agent chat logs.

| Method | MCQ correct | FITB correct | FITB numeric exact | FITB drop | Exact drop | MCQ total tok | FITB total tok | MCQ tok/q | FITB tok/q | MCQ steps/q | FITB steps/q |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-5.4 + TOC | 131/182 (72.0%) | 101/182 (55.5%) | 41/182 (22.5%) | -16.5 | -49.5 | 10,625,428 | 7,867,266 | 58,381 | 43,227 | 9.4 | 8.1 |
| GPT-5.4 + Raw100k | 127/182 (69.8%) | 105/182 (57.7%) | 90/182 (49.5%) | -12.1 | -20.3 | 12,820,358 | 11,100,102 | 70,442 | 60,990 | 7.4 | 7.0 |
| GPT-5.4 + Raw500k | 133/182 (73.1%) | 107/182 (58.8%) | 102/182 (56.0%) | -14.3 | -17.0 | 21,357,632 | 21,592,756 | 117,350 | 118,642 | 7.2 | 7.0 |
| Sonnet 4.6 + TOC | 155/182 (85.2%) | 116/182 (63.7%) | 78/182 (42.9%) | -21.4 | -42.3 | 18,628,237 | 11,238,220 | 102,353 | 61,748 | 10.5 | 7.9 |

## Agreement: MCQ Correct vs FITB Correct

| Method | Both correct | MCQ-only | FITB-only | Both wrong |
| --- | --- | --- | --- | --- |
| GPT-5.4 + TOC | 87 | 44 | 14 | 37 |
| GPT-5.4 + Raw100k | 88 | 39 | 17 | 38 |
| GPT-5.4 + Raw500k | 96 | 37 | 11 | 38 |
| Sonnet 4.6 + TOC | 113 | 42 | 3 | 24 |

## Agreement: MCQ Correct vs FITB Numeric Exact

| Method | MCQ correct and FITB exact | MCQ correct but FITB not exact | FITB exact but MCQ wrong |
| --- | --- | --- | --- |
| GPT-5.4 + TOC | 37 | 94 | 4 |
| GPT-5.4 + Raw100k | 75 | 52 | 15 |
| GPT-5.4 + Raw500k | 91 | 42 | 11 |
| Sonnet 4.6 + TOC | 76 | 79 | 2 |
